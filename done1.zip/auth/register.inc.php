<?php
session_start();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/mail.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . BASE_URL . '/register.php');
    exit;
}

$username = trim($_POST['username'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

if ($username === '' || $email === '' || $password === '') {
    header('Location: ' . BASE_URL . '/register.php?register=failed&email-not-verified');
    die('All fields are required');
    exit;
}

if (mb_strlen($username) < 5) {
    header('Location: ' . BASE_URL . '/register.php?register=failed&email-5-characters');
    die('Username must be at least 5 characters');
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header('Location: ' . BASE_URL . '/register.php?register=failed&email-invalid');
    die('Invalid email format');
    exit;
}

if (strlen($password) < 6) {
    header('Location: ' . BASE_URL . '/register.php?register=failed&password-6-characters');
    die('Password must be at least 6 characters');
    exit;
}

$stmt = $conn->prepare('SELECT id FROM users WHERE email = ?');
if (!$stmt) {
    die('Prepare failed: ' . $conn->error);
}
$stmt->bind_param('s', $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    header('Location: ' . BASE_URL . '/register.php?register=failed&email-already-registered');
    die('Email already registered');
    exit;
}

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
$token = bin2hex(random_bytes(32));

$stmt = $conn->prepare('INSERT INTO users (username, email, password, verification_token) VALUES (?, ?, ?, ?)');
if (!$stmt) {
    die('Insert prepare failed: ' . $conn->error);
}
$stmt->bind_param('ssss', $username, $email, $hashedPassword, $token);
if (!$stmt->execute()) {
    die('Insert failed: ' . $stmt->error);
}

$link = BASE_URL . '/auth/verify.php?token=' . urlencode($token);

$message = sprintf('
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Verify Your Email</title>
</head>
<body style="margin:0;padding:0;background:#f4f4f4;font-family:Arial,Helvetica,sans-serif;">
<table width="100%%" cellpadding="0" cellspacing="0" border="0" style="background:#f4f4f4;padding:40px 0;">
<tr>
<td align="center">
<table width="600" cellpadding="0" cellspacing="0" border="0"
style="background:#ffffff;border-radius:12px;overflow:hidden;
box-shadow:0 4px 15px rgba(0,0,0,.08);">
<tr>
<td align="center"
style="background:#111827;padding:35px;">
<img src="site.png"
width="60"
alt="Logo"
style="display:block;margin-bottom:15px;">

<h1 style="color:#ffffff;font-size:28px;margin:0;">
Techsolnews.com
</h1>

</td>
</tr>

<tr>
<td style="padding:40px;">

<h2 style="margin:0 0 20px;color:#111827;font-size:26px;">
Verify Your Email Address
</h2>

<p style="margin:0 0 20px;color:#555;font-size:16px;line-height:26px;">
We received a request to verify your email address.
If you made this request, click the button below.
</p>

<table cellpadding="0" cellspacing="0" border="0" align="center">
<tr>
<td bgcolor="#22c55e" style="border-radius:8px;">
<a href="%s"
style="display:inline-block;padding:15px 35px;
color:#ffffff;
text-decoration:none;
font-size:16px;
font-weight:bold;">
Verify Email
</a>
</td>
</tr>
</table>

<p style="word-break:break-all;background:#f8f8f8;padding:12px;border-radius:6px;font-size:13px;color:#333;">%s</p>

<hr style="border:none;border-top:1px solid #eee;margin:35px 0;">

<p style="font-size:13px;color:#777;line-height:22px;">
This verification link expires in <strong>30 minutes</strong>.
If you didn\'t request to verify your email, you can safely ignore this email.
</p>


</td>
</tr>

<tr>
<td align="center"
style="padding:25px;
background:#f9f9f9;
color:#999;
font-size:12px;">

© %d Techsolnews.com. All rights reserved.

</td>
</tr>

</table>

</td>
</tr>
</table>

</body>
</html>',
htmlspecialchars($link, ENT_QUOTES, 'UTF-8'),
htmlspecialchars($link, ENT_QUOTES, 'UTF-8'),
date('Y')
);

$mailStatus = sendMail($email, 'Verify your email', $message);

$_SESSION['verify_alert'] = $mailStatus === true
    ? 'Please verify your email.'
    : 'Registration was successful, but the verification email could not be sent.';

header('Location: ' . BASE_URL . '/login.php?register=success' . ($mailStatus === true ? '&verify=emailsent' : ''));
exit;
