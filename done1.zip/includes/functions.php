<?php
// HTML Encodes special characters to prevent XSS attacks
function escape($data)
{
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}
// Generates a secure random token for password reset
function generateToken() {
    return bin2hex(random_bytes(32));
}
// Checks if the provided token has expired based on the expiry timestamp
function isTokenExpired($expiry) {
    return strtotime($expiry) < time();
}
