<?php
session_start();
require_once 'config/db.php';
require_once 'includes/functions.php';

if (empty($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
?>
<?php require_once 'includes/header.php'; ?>

<div class="con-dash">
<!-- Left side 30% -->
<div class="left-side-dash">
    <h3>Info</h3>
    <p>Welcome to your dashboard! Here you can manage your account, view your activity, and access exclusive content.</p>
    <p>Username: <?php echo htmlspecialchars($_SESSION['username'] ?? 'User', ENT_QUOTES, 'UTF-8'); ?></p>
    <p>Email: <?php echo htmlspecialchars($_SESSION['email'] ?? 'Not provided', ENT_QUOTES, 'UTF-8'); ?></p>
    <button class="logout-btn" onclick="window.location.href='auth/logout.php'">Logout</button>
</div>

<!-- Main content 70% -->
<div class="right-side-dash">
    <h1>Hi, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User', ENT_QUOTES, 'UTF-8'); ?>! Welcome to your dashboard</h1>
    <p>This is the main content area for the dashboard.</p>
</div>
</div>


<?php require_once 'includes/footer.php'; ?>